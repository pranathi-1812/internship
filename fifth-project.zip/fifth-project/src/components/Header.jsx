import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

// Importing icons
import dashboardIcon from '../../assets/icons/dashboard.png';
import profileIcon from 'src\assets\icons\My Profile.svg';
import applicationsIcon from 'src\assets\icons\My Applications.svg';
import jobsIcon from 'src\assets\icons\Find Jobs.svg';
import interviewsIcon from 'src\assets\icons\Interviews.svg';
import documentsIcon from 'src\assets\icons\Documents.svg';

const Header = () => {
  return (
    <div className="header">
      <h2 className="header-title">Opportunity Hub</h2>
      <nav className="nav-menu">
        <Link to="/" className="nav-item">
          <img src={dashboardIcon} alt="Dashboard" className="nav-icon" />
          Dashboard
        </Link>
        <Link to="/profile" className="nav-item">
          <img src={profileIcon} alt="My Profile" className="nav-icon" />
          My Profile
        </Link>
        <Link to="/applications" className="nav-item">
          <img src={applicationsIcon} alt="My Applications" className="nav-icon" />
          My Applications
        </Link>
        <Link to="/jobs" className="nav-item">
          <img src={jobsIcon} alt="Find Jobs" className="nav-icon" />
          Find Jobs
        </Link>
        <Link to="/interviews" className="nav-item">
          <img src={interviewsIcon} alt="Interviews" className="nav-icon" />
          Interviews
        </Link>
        <Link to="/documents" className="nav-item">
          <img src={documentsIcon} alt="Documents" className="nav-icon" />
          Documents
        </Link>
      </nav>
    </div>
  );
};

export default Header;
