export { default as DocumentUpload } from './DocumentUpload';
