import React from 'react';
import './DocumentUpload.css';

const DocumentUpload = () => {
  const handleSubmit = () => {
    alert("Documents submitted successfully!");
  };

  return (
    <div className="document-upload-wrapper">
      <div className="document-upload">
        <h1>Upload Documents</h1>

        <div className="section">
          <h2>Educational Documents</h2>
          <div className="form-group">
            <label>Attach your 10 marks card</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
          <div className="form-group">
            <label>Attach your 12 marks card</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
          <div className="form-group">
            <label>Attach your graduation transcript</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
        </div>

        <div className="section">
          <h2>Skills</h2>
          <div className="form-group">
            <label>Attach your resume</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
          <div className="form-group">
            <label>Attach your certification</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
        </div>

        <div className="section">
          <h2>Personal Documents</h2>
          <div className="form-group">
            <label>Attach your Aadhaar card</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
          <div className="form-group">
            <label>Attach your Pancard</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
          <div className="form-group">
            <label>Attach your passport</label>
            <button className="attach-btn">📎 Attach</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentUpload;
