import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import DocumentUpload from './components/DocumentUpload/DocumentUpload';
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import './App.css';

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <Header />
        <div className="content-container">
          <Routes>
            <Route path="/" element={<DocumentUpload />} />
          </Routes>
        </div>
      </div>
      <Footer /> {/* Ensure Footer is placed here */}
    </Router>
  );
};

export default App;
